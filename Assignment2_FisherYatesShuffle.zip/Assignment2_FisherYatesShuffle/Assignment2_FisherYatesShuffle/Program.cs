﻿using System;
using static System.Console;
using System.IO;


namespace Assignment2_FisherYatesShuffle
{
    class Program
    {
        static void Main()
        {
            string DataFile = "Brownpaperbag.txt";
            var lines = File.ReadAllLines(DataFile);
            lines.MakeWordsShuffle();
            File.WriteAllLines("Brownpaperbag.txt", lines);
              foreach (string phrase in lines)
                  Write(phrase + "\n ");
              ReadKey();

          
        }
    }
        
    
}
