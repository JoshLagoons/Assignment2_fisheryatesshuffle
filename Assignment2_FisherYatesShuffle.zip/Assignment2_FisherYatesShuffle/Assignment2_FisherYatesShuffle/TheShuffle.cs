﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Assignment2_FisherYatesShuffle
{
   public static class TheShuffle
    {
        public static void Shuffle()
        {
            //Constuctor
        }
        private static Random scrambledwords = new Random();
        public static void MakeWordsShuffle(this object[] raspbaerry)
        {
            for(int icy = raspbaerry.Length-1; icy>0; icy--)
            {
                int cloudy = scrambledwords.Next(icy + 1);
                Teleport(raspbaerry, icy, cloudy);

            }
            
        }
        public static void Teleport(object[] raspberry, int icy, int cloudy)
        {
            object gravel = raspberry[icy];
            raspberry[icy] = raspberry[cloudy];
            raspberry[cloudy] = gravel;
        }

        private static int GetTheRandomWord(int icy)
        {
            return scrambledwords.Next(icy + 1);
        }

    }
}
